
# Prague AI Travel SaaS Platform

## Stack
- Next.js
- Prisma (Postgres)
- NextAuth (Auth)
- Stripe (billing-ready scaffold)

## Run
npm install
npm run dev

## SaaS upgrade path
1. Add Supabase/Postgres
2. Enable NextAuth providers (Google)
3. Add Stripe subscriptions
4. Multi-tenant org dashboards
5. Real-time travel agent API
