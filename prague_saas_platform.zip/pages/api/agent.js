
import { runAgent } from "../../lib/agent";

export default function handler(req,res){
  const { trip, weather } = req.body;

  const plan = runAgent(trip, weather || {condition:"CLEAR"});

  res.json({ plan });
}
