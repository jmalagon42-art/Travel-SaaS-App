
import NextAuth from "next-auth";

export default NextAuth({
  providers: [],
  session: { strategy: "jwt" }
});
