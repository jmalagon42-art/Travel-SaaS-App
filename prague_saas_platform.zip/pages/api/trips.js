
let trips = [];

export default function handler(req,res){
  if(req.method === "POST"){
    trips.push(req.body);
    return res.json(trips);
  }
  res.json(trips);
}
