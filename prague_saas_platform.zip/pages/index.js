
import { useState } from "react";

export default function Home(){
  const [plan,setPlan] = useState(null);

  async function run(){
    const res = await fetch("/api/agent",{
      method:"POST",
      headers:{ "Content-Type":"application/json" },
      body: JSON.stringify({
        trip:{
          stops:[
            {name:"Municipal House",type:"outdoor",priority:5},
            {name:"Cafe Imperial",type:"indoor",priority:5}
          ],
          userFatigue:1
        },
        weather:{condition:"RAIN"}
      })
    });

    setPlan(await res.json());
  }

  return (
    <div style={{padding:20}}>
      <h1>🧭 Prague SaaS Travel Platform</h1>
      <button onClick={run}>Generate AI Plan</button>

      {plan && plan.plan.map((p,i)=>(
        <div key={i} style={{margin:10,padding:10,border:"1px solid #ccc"}}>
          {p.name} — Score {p.score}
        </div>
      ))}
    </div>
  );
}
